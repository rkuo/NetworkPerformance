#0000000001111111111222222222233333333334444444444555555555566666666667777777777888888888899999999990000000000111111111122222222223
#1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
#  PID  P nTH USER      PR  NI    VIRT    RES    DATA    SHR S  %CPU %MEM     TIME+ COMMAND
# 9645  3   1 hom       20   0  124464   2520    1884   1184 R   1.3  0.0   0:00.67 top

col_txt={}
col_start={}
col_end={}
col_txt[1]="PID";col_start[1]=1;col_end[1]=5
col_txt[2]="P";col_start[2]=6;col_end[2]=8
col_txt[3]="nTH";col_start[3]=9;col_end[3]=12
col_txt[4]="USER";col_start[4]=13;col_end[4]=21
col_txt[5]="PR";col_start[5]=22;col_end[5]=25
col_txt[6]="NI";col_start[6]=26;col_end[6]=29
col_txt[7]="VIRT";col_start[7]=30;col_end[7]=37
col_txt[8]="RES";col_start[8]=38;col_end[8]=44
col_txt[9]="DATA";col_start[9]=45;col_end[9]=52
col_txt[10]="SHR";col_start[10]=53;col_end[10]=59
col_txt[11]="S";col_start[11]=60;col_end[11]=61
col_txt[12]="%CPU";col_start[12]=62;col_end[12]=67
col_txt[13]="%MEM";col_start[13]=68;col_end[13]=72
col_txt[14]="TIME+";col_start[14]=73;col_end[14]=82
col_txt[15]="COMMAND";col_start[15]=83;col_end[15]=150

